#!/usr/bin/env python
# coding: utf-8

# In[16]:

import pandas as pd

from pymongo import MongoClient
from bson.objectid import ObjectId
pd.read_csv("aac_shelter_outcomes.csv")

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    pd.read_csv("aac_shelter_outcomes.csv")

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'meow'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 34675
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client[DB]
        self.collection = self.database[COL]
        
        
        #self.list_database_names()
        #cursor = collection.find({"animal_type":"Cat"})
        #list(cursor)
        
        
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        try:
            
            result = self.database.animals.insert_one(data)  # data should be dictionary
            return True if result.inserted_id != 0 else False
        except Exception as e:
            print(f"Error inserting the document {e}")
            return False

# Create method to implement the R in CRUD.
    def read(self, query):
        if query is not None:
            documents = list(self.database.animals.find(query))
            return documents
        else:
            print("Error querying documents: {e}")
            return query
            
        
# create method for the U in CRUD, can you tell i like Try methods
    def update(self, query, updateData):
        try:
            self.database.animals.update_many(query, {"$set":updateData})
            return True if query != 0 and updateData != 0 else False
        except Exception as e:
            print(f"Error updating the document {e}")
            return False

# create method for the D in CRUD
    def delete(self, query):
        try:
            self.database.animals.delete_many(query)
            return True if query != 0 else False
        except Exception as e:
            print(f"Error deleting document {e}")
            return False
animals = ["","age_upon_outcome","animal_id","animal_type","breed","color","date_of_birth","datetime","monthyear","name","outcome_subtype","outcome_type","sex_upon_outcome","location_lat","location_long","age_upon_outcome_in_weeks"]

animals.append({"1","3 years","A746874","Cat","Domestic Shorthair Mix","Black/White",2014-4-10,2017-4-11 ,"2017-04-11T09:00:00","","SCRP","Transfer","Neutered Male",30.5066578739455,-97.3408780722188,156.767857142857,
"2","1 year","A725717","Cat","Domestic Shorthair Mix","Silver Tabby",2015-5-2,2016-5-6 ,"2016-05-06T10:49:00","v","SCRP","Transfer","Spayed Female",30.6525984560228,-97.7419963476444,52.9215277777778,
"3","2 years","A716330","Dog","Chihuahua Shorthair Mix","Brown/White",2013-11-18,2015-12-28 ,"2015-12-28T18:43:00","Frank","","Adoption","Neutered Male",30.7595748121648,-97.5523753807133,110.111408730159,
"4","7 months","A733653","Cat","Siamese Mix","Seal Point",2016-1-25,2016-8-27 ,"2016-08-27T18:11:00","Kitty","","Adoption","Intact Female",30.3188063374257,-97.7240376703891,30.8225198412698,
"5","2 years","A691584","Dog","Labrador Retriever Mix","Tan/White",2012-11-6,2015-5-30,"2015-05-30T13:48:00","Luke","","Return to Owner","Neutered Male",30.7104815618433,-97.562297435286,133.653571428571,
"6","5 years","A696004","Dog","Cardigan Welsh Corgi Mix","Sable/White",2010-1-27,2015-1-28 ,"2015-01-28T10:39:00","Lucy","Rabies Risk","Euthanasia","Spayed Female",30.6737365854231,-97.707971529467,261.063392857143}
)

# In[ ]:




